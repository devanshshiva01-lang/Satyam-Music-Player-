# Keep Media3 service/session classes discoverable when shrinking.
-keep class androidx.media3.** { *; }
