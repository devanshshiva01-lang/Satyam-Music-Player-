package com.satyam.musicplayer.data

import android.net.Uri

data class MediaItemData(
    val id: Long,
    val title: String,
    val artist: String,
    val uri: Uri,
    val durationMs: Long,
    val isVideo: Boolean
)
