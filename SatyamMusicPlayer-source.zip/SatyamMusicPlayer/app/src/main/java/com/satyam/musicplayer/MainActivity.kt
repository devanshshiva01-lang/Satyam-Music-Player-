package com.satyam.musicplayer

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as PlayerMediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.satyam.musicplayer.data.MediaItemData
import com.satyam.musicplayer.data.MediaRepository
import com.satyam.musicplayer.playback.PlaybackService
import com.satyam.musicplayer.ui.GlassCard
import com.satyam.musicplayer.ui.GlassTheme
import com.satyam.musicplayer.ui.formatDuration
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var controllerState by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({ runCatching { controller = future.get(); controllerState = controller } }, mainExecutor)
        }
        setContent {
            val scope = rememberCoroutineScope()
            val repository = remember { MediaRepository(this) }
            var audio by remember { mutableStateOf<List<MediaItemData>>(emptyList()) }
            var videos by remember { mutableStateOf<List<MediaItemData>>(emptyList()) }
            var tab by remember { mutableStateOf("Songs") }
            var query by remember { mutableStateOf("") }
            var permissionReady by remember { mutableStateOf(hasMediaPermission()) }
            val activeController = controllerState
            var currentTitle by remember { mutableStateOf("Choose a song to begin") }
            var currentIsVideo by remember { mutableStateOf(false) }
            var isPlaying by remember { mutableStateOf(false) }
            var duration by remember { mutableLongStateOf(0L) }
            var position by remember { mutableLongStateOf(0L) }
            val permissions = remember {
                if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
                else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
                permissionReady = result.values.any { it } || hasMediaPermission()
                if (permissionReady) scope.launch { audio = repository.scan(true); videos = repository.scan(false) }
            }
            LaunchedEffect(permissionReady) {
                if (permissionReady) { audio = repository.scan(true); videos = repository.scan(false) }
            }
            DisposableEffect(activeController) {
                val c = activeController
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                    override fun onMediaItemTransition(mediaItem: PlayerMediaItem?, reason: Int) {
                        currentTitle = mediaItem?.mediaMetadata?.title?.toString() ?: "Satyam Music Player"
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        duration = c?.duration?.coerceAtLeast(0L) ?: 0L
                    }
                }
                c?.addListener(listener)
                onDispose { c?.removeListener(listener) }
            }
            LaunchedEffect(activeController, isPlaying) {
                while (activeController != null && isPlaying) {
                    position = activeController.currentPosition.coerceAtLeast(0L)
                    duration = activeController.duration.coerceAtLeast(0L)
                    kotlinx.coroutines.delay(500)
                }
            }
            GlassTheme {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF11172E), Color(0xFF080A14), Color(0xFF111022))))) {
                    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Satyam Music Player", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Text("Your music. Your moment.", color = Color(0xFFB9C2E3), fontSize = 13.sp)
                            }
                            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color(0xFF9B8CFF), modifier = Modifier.size(34.dp))
                        }
                        Spacer(Modifier.height(20.dp))
                        OutlinedTextField(
                            value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search songs and videos", color = Color(0xFF9EA7C5)) },
                            leadingIcon = { Icon(Icons.Default.Search, null, tint = Color(0xFFB7BFE0)) },
                            singleLine = true, shape = RoundedCornerShape(22.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0x889B8CFF), unfocusedBorderColor = Color(0x44FFFFFF),
                                cursorColor = Color.White, focusedContainerColor = Color(0x22FFFFFF), unfocusedContainerColor = Color(0x16FFFFFF)
                            )
                        )
                        Spacer(Modifier.height(14.dp))
                        if (currentIsVideo && activeController != null) {
                            AndroidView(
                                factory = { context -> androidx.media3.ui.PlayerView(context).apply { player = activeController; useController = false; setShowBuffering(androidx.media3.ui.PlayerView.SHOW_BUFFERING_WHEN_PLAYING) } },
                                update = { it.player = activeController },
                                modifier = Modifier.fillMaxWidth().height(210.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("Songs", "Videos").forEach { label ->
                                FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) },
                                    leadingIcon = { Icon(if (label == "Songs") Icons.Default.MusicNote else Icons.Default.Movie, null, Modifier.size(17.dp)) })
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { if (hasMediaPermission()) scope.launch { audio = repository.scan(true); videos = repository.scan(false) } else permissionLauncher.launch(permissions) }) {
                                Icon(Icons.Default.Refresh, "Refresh library", tint = Color.White)
                            }
                        }
                        if (!permissionReady) {
                            GlassCard(Modifier.fillMaxWidth()) {
                                Text("Allow media access to find music and videos stored on your phone.", color = Color.White)
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = { permissionLauncher.launch(permissions) }) { Text("Scan my library") }
                            }
                        } else {
                            val all = if (tab == "Songs") audio else videos
                            val filtered = all.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
                            Text(if (tab == "Songs") "YOUR LIBRARY · ${filtered.size} TRACKS" else "YOUR LIBRARY · ${filtered.size} VIDEOS",
                                color = Color(0xFFADB8DD), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp,
                                modifier = Modifier.padding(vertical = 10.dp))
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                                items(filtered, key = { "${it.isVideo}-${it.id}" }) { item ->
                                    GlassCard(Modifier.fillMaxWidth().clickable {
                                        val c = activeController
                                        if (c != null) {
                                            val playlist = filtered.map { media ->
                                                PlayerMediaItem.Builder().setUri(media.uri)
                                                    .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(media.title).setArtist(media.artist).build()).build()
                                            }
                                            c.setMediaItems(playlist, filtered.indexOf(item), 0L)
                                            c.prepare(); c.play(); currentTitle = item.title; currentIsVideo = item.isVideo
                                        }
                                    }) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(Modifier.size(46.dp).background(Color(0x337F78FF), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                                Icon(if (item.isVideo) Icons.Default.PlayCircle else Icons.Default.MusicNote, null, tint = Color(0xFFD4D0FF), modifier = Modifier.size(25.dp))
                                            }
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(item.title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(if (item.isVideo) "Video · ${formatDuration(item.durationMs)}" else "${item.artist} · ${formatDuration(item.durationMs)}",
                                                    color = Color(0xFFAEB7D7), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                                        }
                                    }
                                }
                                if (filtered.isEmpty()) item { Text("No media found here yet.", color = Color(0xFFB9C2E3), modifier = Modifier.padding(18.dp)) }
                            }
                        }
                        GlassCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).background(Brush.linearGradient(listOf(Color(0xFF8277FF), Color(0xFF35BCEB))), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.GraphicEq, null, tint = Color.White)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(currentTitle, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                    Text("${formatDuration(position)} / ${formatDuration(duration)}", color = Color(0xFFB6BFDF), fontSize = 11.sp)
                                }
                                IconButton(onClick = { activeController?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
                                IconButton(onClick = { activeController?.let { if (it.isPlaying) it.pause() else it.play() } }) {
                                    Icon(if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled, "Play or pause", tint = Color(0xFFD6D0FF), modifier = Modifier.size(34.dp))
                                }
                                IconButton(onClick = { activeController?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
                            }
                            if (duration > 0) Slider(value = position.toFloat().coerceIn(0f, duration.toFloat()), onValueChange = { position = it.toLong() }, onValueChangeFinished = { activeController?.seekTo(position) }, valueRange = 0f..duration.toFloat(), modifier = Modifier.height(24.dp))
                        }
                    }
                }
            }
        }
    }

    private fun hasMediaPermission(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
