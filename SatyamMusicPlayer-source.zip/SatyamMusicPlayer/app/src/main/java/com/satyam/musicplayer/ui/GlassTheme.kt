package com.satyam.musicplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val GlassColors = darkColorScheme(
    primary = Color(0xFFB6AAFF), secondary = Color(0xFF77D8FF),
    background = Color(0xFF080A14), surface = Color(0xFF171B2C), onPrimary = Color(0xFF100D25),
    onBackground = Color.White, onSurface = Color.White
)

@Composable
fun GlassTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GlassColors, content = content)
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = modifier.clip(shape)
            .background(Brush.linearGradient(listOf(Color(0x2EFFFFFF), Color(0x12A9B8FF), Color(0x16FFFFFF))))
            .border(1.dp, Brush.linearGradient(listOf(Color(0x66FFFFFF), Color(0x228F9DFF), Color(0x33FFFFFF))), shape)
            .padding(13.dp),
        content = content
    )
}

fun formatDuration(milliseconds: Long): String {
    val seconds = (milliseconds.coerceAtLeast(0L) / 1000L)
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
