package com.satyam.musicplayer.data

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {
    suspend fun scan(audio: Boolean): List<MediaItemData> = withContext(Dispatchers.IO) {
        val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = if (audio) arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION
        ) else arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION
        )
        val selection = if (audio) "${MediaStore.Audio.Media.IS_MUSIC} != 0" else null
        val sort = if (audio) "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
                   else "${MediaStore.Video.Media.TITLE} COLLATE NOCASE ASC"
        val result = mutableListOf<MediaItemData>()
        try { context.contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(if (audio) MediaStore.Audio.Media._ID else MediaStore.Video.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(if (audio) MediaStore.Audio.Media.TITLE else MediaStore.Video.Media.TITLE)
            val durationCol = cursor.getColumnIndexOrThrow(if (audio) MediaStore.Audio.Media.DURATION else MediaStore.Video.Media.DURATION)
            val artistCol = if (audio) cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST) else -1
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                val title = cursor.getString(titleCol) ?: "Unknown title"
                val artist = if (artistCol >= 0) cursor.getString(artistCol) ?: "Unknown artist" else "Video"
                val duration = cursor.getLong(durationCol)
                result += MediaItemData(id, title, artist, uri, duration, !audio)
            }
        } } catch (_: SecurityException) { return@withContext emptyList() }
        result
    }
}
