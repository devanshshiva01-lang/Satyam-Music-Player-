# Satyam Music Player — Android starter project

A local-first Android audio/video player starter with a Liquid Glass-inspired dark UI, MediaStore library scanning, search, playlist-queue playback, and Media3 `MediaSessionService` background playback.

## Current implementation
- Package: `com.satyam.musicplayer`
- App label: **Satyam Music Player**
- Minimum Android: 8.0 / API 26
- Target/compile SDK: 35 (update to the current Google Play target API requirement before publishing)
- Kotlin + Jetpack Compose + AndroidX Media3
- Local audio/video indexing via MediaStore; no cloud account or server required
- Background playback service and media session
- Debug APK / release APK / Play Store AAB build configurations

## Build in Android Studio
1. Install the current stable Android Studio and Android SDK Platform 36 (or update SDK values in `app/build.gradle.kts` to the installed/current required API).
2. Open this folder (`SatyamMusicPlayer`) as an existing project.
3. Allow Gradle sync to download dependencies.
4. Connect an Android 8+ device with USB debugging enabled, or start an emulator.
5. Run the `app` configuration. Grant media permissions when prompted.

## Build outputs
From the project directory, with Android SDK and Gradle available:

```bash
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew bundleRelease
```

Expected output locations:
- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/apk/release/app-release-unsigned.apk` (unless signing is configured)
- `app/build/outputs/bundle/release/app-release.aab`

For Play Store publishing, configure a private release signing key in local Gradle properties or Android Studio's signing wizard. Never commit the keystore or passwords into source control.

## Format support and honest limitations
Media3 uses Android's available platform decoders and supports many common containers/codecs. A filename extension does not guarantee playback: the codec profile, bit depth, resolution, damaged-file state, and device decoder all matter. This starter does **not** yet bundle FFmpeg or guarantee every AVI/MOV/WMV/MKV variant. Add a maintained, license-reviewed decoder integration only after deciding acceptable APK size and licensing obligations. Test a real corpus of files on several devices.

## Next engineering steps before production
- Run Gradle sync/build and fix any version/API issues in the target Android Studio environment.
- Add automated tests, crash reporting opt-in, and accessibility checks.
- Expand video controls and validate `PlayerView` lifecycle/orientation behavior across devices.
- Add robust media refresh handling, queue persistence, artwork caching, folder browsing, subtitles, audio focus/headset behavior, and error feedback.
- Tune permission handling for Android 14+ partial media access and Play policy.
- Update target API to current Play requirements and prepare privacy policy/store listing before publishing.

This is a starter source project, not a verified production release. The environment in which it was generated did not have Android SDK/Gradle build tools, so no APK/AAB was compiled or device-tested here.
